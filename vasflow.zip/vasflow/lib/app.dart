import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

class VasFlowApp extends StatefulWidget {
  const VasFlowApp({super.key});
  @override State<VasFlowApp> createState() => VasFlowAppState();
}

class VasFlowAppState extends State<VasFlowApp> {
  ThemeMode mode = ThemeMode.light;
  void toggleTheme(bool dark) => setState(() => mode = dark ? ThemeMode.dark : ThemeMode.light);

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VasFlow',
    debugShowCheckedModeBanner: false,
    themeMode: mode,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3478F6)), useMaterial3: true, brightness: Brightness.light, scaffoldBackgroundColor: const Color(0xFFF5F7FB), cardTheme: const CardTheme(elevation: 0, margin: EdgeInsets.zero)),
    darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6B9BFF), brightness: Brightness.dark), useMaterial3: true, brightness: Brightness.dark, cardTheme: const CardTheme(elevation: 0, margin: EdgeInsets.zero)),
    supportedLocales: const [Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: LoginScreen(onThemeChanged: toggleTheme, isDark: mode == ThemeMode.dark),
  );
}
