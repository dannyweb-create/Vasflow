import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:csv/csv.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../models/client_record.dart';
import '../services/auth_service.dart';
import '../services/client_repository.dart';
import '../services/local_store.dart';

class ClientsScreen extends StatefulWidget {
  final AuthService auth; final bool exportOnly;
  const ClientsScreen({super.key, required this.auth, this.exportOnly = false});
  @override State<ClientsScreen> createState() => _ClientsScreenState();
}
class _ClientsScreenState extends State<ClientsScreen> {
  final repo = ClientRepository(LocalStore());
  final search = TextEditingController();
  List<ClientRecord> clients = [];
  bool loading = true;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { final c = await repo.all(); if (mounted) setState(() { clients = c; loading = false; }); }
  List<ClientRecord> get filtered => clients.where((c) => '${c.fullName} ${c.email} ${c.phone} ${c.country}'.toLowerCase().contains(search.text.toLowerCase())).toList();
  Future<void> addOrEdit([ClientRecord? old]) async {
    final name = TextEditingController(text: old?.fullName ?? '');
    final email = TextEditingController(text: old?.email ?? '');
    final phone = TextEditingController(text: old?.phone ?? '');
    final country = TextEditingController(text: old?.country ?? '');
    final uni = TextEditingController(text: old?.university ?? '');
    final passport = TextEditingController(text: old?.passportNumber ?? '');
    final notes = TextEditingController(text: old?.notes ?? '');
    String stage = old?.stage ?? 'New lead';
    final stages = ['New lead','Consultation','Documents','Application submitted','Visa decision','Completed'];
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => AlertDialog(
      title: Text(old == null ? 'Add client' : 'Edit client'),
      content: SizedBox(width: 440, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        _field(name,'Full name *'), _field(email,'Email'), _field(phone,'Phone'), _field(country,'Preferred country'), _field(uni,'Preferred university'), _field(passport,'Passport number'), _field(notes,'Notes', lines: 3),
        DropdownButtonFormField<String>(value: stage, decoration: const InputDecoration(labelText: 'Pipeline stage'), items: stages.map((s) => DropdownMenuItem(value:s, child:Text(s))).toList(), onChanged:(v) => setD(() => stage = v ?? stages.first)),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx,false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx,true), child: const Text('Save'))],
    )));
    if (ok == true && name.text.trim().isNotEmpty) {
      final rec = ClientRecord(id: old?.id ?? LocalStore().newId(), fullName: name.text.trim(), email: email.text.trim(), phone: phone.text.trim(), country: country.text.trim(), university: uni.text.trim(), passportNumber: passport.text.trim(), notes: notes.text.trim(), stage: stage, updatedAt: DateTime.now(), visaStatus: old?.visaStatus ?? 'Not started');
      try { await repo.upsert(rec); await load(); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved locally; online sync failed: $e'))); }
    }
  }
  Widget _field(TextEditingController c, String label, {int lines = 1}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller:c, maxLines:lines, decoration: InputDecoration(labelText:label, border:const OutlineInputBorder())));
  Future<void> exportCsv() async {
    final rows = <List<dynamic>>[['Name','Email','Phone','Country','University','Passport','Visa status','Stage','Updated']];
    rows.addAll(filtered.map((c) => [c.fullName,c.email,c.phone,c.country,c.university,c.passportNumber,c.visaStatus,c.stage,DateFormat('yyyy-MM-dd').format(c.updatedAt)]));
    final content = const ListToCsvConverter().convert(rows);
    final path = await FilePicker.platform.saveFile(dialogTitle:'Export VasFlow clients', fileName:'vasflow-clients.csv', type:FileType.custom, allowedExtensions:['csv']);
    if (path != null) { await File(path).writeAsString(content); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('CSV exported'))); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.exportOnly ? 'Reports & export' : 'Clients'), actions: [IconButton(tooltip:'Export CSV', onPressed:exportCsv, icon:const Icon(Icons.file_download_outlined)), if (!widget.exportOnly) IconButton(tooltip:'Add client', onPressed:() => addOrEdit(), icon:const Icon(Icons.add))]),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(controller:search, onChanged:(_) => setState((){}), decoration: const InputDecoration(prefixIcon:Icon(Icons.search), hintText:'Search clients by name, email, phone or country', border:OutlineInputBorder()))),
      Expanded(child: loading ? const Center(child:CircularProgressIndicator()) : filtered.isEmpty ? const Center(child:Text('No clients yet. Tap + to add your first client.')) : ListView.separated(itemCount:filtered.length, separatorBuilder:(_,__)=>const Divider(height:1), itemBuilder:(ctx,i) {
        final c=filtered[i];
        return ListTile(leading:CircleAvatar(child:Text(c.fullName.isEmpty?'?':c.fullName[0].toUpperCase())), title:Text(c.fullName, style:const TextStyle(fontWeight:FontWeight.w600)), subtitle:Text('${c.country.isEmpty?'Country not set':c.country} · ${c.stage}\\n${c.email.isEmpty?c.phone:c.email}', maxLines:2), isThreeLine:true, trailing:PopupMenuButton<String>(onSelected:(v) async { if(v=='edit') await addOrEdit(c); if(v=='documents') { if (!mounted) return; await FilePicker.platform.pickFiles(allowMultiple:true); } if(v=='delete') { if(widget.auth.role!='admin') { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Only an Admin can delete critical data.'))); return; } final yes=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Delete client?'),content:Text('Delete ${c.fullName}?'),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Delete'))])); if(yes==true) { await repo.delete(c.id); await load(); } } }, itemBuilder:(_) => const [PopupMenuItem(value:'edit',child:Text('Edit profile')),PopupMenuItem(value:'documents',child:Text('Choose documents')),PopupMenuItem(value:'delete',child:Text('Delete (Admin only)'))]), onTap:() => showDialog(context:context,builder:(_) => AlertDialog(title:Text(c.fullName),content:Text('Email: ${c.email}\\nPhone: ${c.phone}\\nCountry: ${c.country}\\nUniversity: ${c.university}\\nPassport: ${c.passportNumber}\\nVisa status: ${c.visaStatus}\\nNotes: ${c.notes}'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])));
      })),
    ]),
  );
}
