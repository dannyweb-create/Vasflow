import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'dashboard_screen.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  final bool isDark;
  const LoginScreen({super.key, required this.onThemeChanged, required this.isDark});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final auth = AuthService();
  final id = TextEditingController(text: AuthService.demoEmail);
  final password = TextEditingController(text: AuthService.demoPassword);
  bool busy = false, obscure = true;
  String? error;

  Future<void> login() async {
    setState(() { busy = true; error = null; });
    try {
      await auth.signIn(id.text, password.text);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => DashboardScreen(auth: auth, onThemeChanged: widget.onThemeChanged, isDark: widget.isDark)));
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.travel_explore_rounded, size: 54, color: Color(0xFF3478F6)),
        const SizedBox(height: 12),
        Text('VasFlow', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text('Visa consultancy, flowing smoothly.', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 32),
        TextField(controller: id, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email or phone number', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: password, obscureText: obscure, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), border: const OutlineInputBorder(), suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => obscure = !obscure)))),
        Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ForgotPasswordScreen())), child: const Text('Forgot password?'))),
        if (error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        FilledButton(onPressed: busy ? null : login, child: Padding(padding: const EdgeInsets.all(13), child: Text(busy ? 'Signing in…' : 'Log in'))),
        const SizedBox(height: 10),
        OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignupScreen())), child: const Text('Create account')),
        const SizedBox(height: 20),
        const Card(child: Padding(padding: EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Demo access', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 5), Text('The demo fields are prefilled. This local demo is not a real Supabase account. Configure Supabase for secure online authentication.'),
        ]))),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Dark mode'), value: widget.isDark, onChanged: widget.onThemeChanged),
      ]),
    ))),
  );
}
