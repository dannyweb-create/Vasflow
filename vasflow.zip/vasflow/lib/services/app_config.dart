/// Replace these values with your Supabase project URL and publishable/anon key.
/// Never put a service_role key in a Flutter client.
class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static const bool demoMode = bool.fromEnvironment('VASFLOW_DEMO_MODE', defaultValue: true);
  static bool get supabaseReady =>
      supabaseUrl.startsWith('https://') && supabaseAnonKey.isNotEmpty;
}
