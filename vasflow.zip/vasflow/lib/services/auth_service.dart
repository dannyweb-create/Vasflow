import 'package:supabase_flutter/supabase_flutter.dart';
import 'app_config.dart';

class AuthService {
  bool get online => AppConfig.supabaseReady;
  bool get demoSession => _demoSession;
  bool _demoSession = false;
  String _demoEmail = '';

  String get currentEmail => online
      ? (Supabase.instance.client.auth.currentUser?.email ?? '')
      : _demoEmail;
  String get role => _demoSession ? 'admin' : 'staff';

  // Demo credentials are for local UI exploration only. Remove before release.
  static const demoEmail = 'wisdomobiomachim@proton.me';
  static const demoPassword = 'Montana@g244';

  Future<void> signIn(String identifier, String password) async {
    if (!online && AppConfig.demoMode) {
      if (identifier.trim().toLowerCase() == demoEmail &&
          password == demoPassword) {
        _demoSession = true;
        _demoEmail = demoEmail;
        return;
      }
      throw Exception('Supabase is not configured. Use the demo credentials or configure Supabase.');
    }
    final client = Supabase.instance.client;
    if (identifier.contains('@')) {
      await client.auth.signInWithPassword(email: identifier.trim(), password: password);
    } else {
      await client.auth.signInWithPassword(phone: identifier.trim(), password: password);
    }
  }

  Future<void> signUp({String? email, String? phone, required String password}) async {
    if (!online) throw Exception('Configure Supabase to create a real account.');
    await Supabase.instance.client.auth.signUp(
      email: email?.trim().isEmpty == true ? null : email?.trim(),
      phone: phone?.trim().isEmpty == true ? null : phone?.trim(),
      password: password,
    );
  }

  Future<void> resetPassword(String email) async {
    if (!online) throw Exception('Password reset requires a configured Supabase project.');
    await Supabase.instance.client.auth.resetPasswordForEmail(email.trim());
  }

  Future<void> signOut() async {
    _demoSession = false;
    _demoEmail = '';
    if (online) await Supabase.instance.client.auth.signOut();
  }
}
