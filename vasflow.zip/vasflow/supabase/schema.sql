-- Run in Supabase SQL Editor after creating your project.
-- Apply and test these policies before storing real client/passport data.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'staff' check (role in ('admin','staff')),
  created_at timestamptz not null default now()
);

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete set null default auth.uid(),
  full_name text not null,
  email text default '',
  phone text default '',
  country text default '',
  university text default '',
  visa_status text default 'Not started',
  passport_number text default '',
  notes text default '',
  stage text default 'New lead',
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.clients enable row level security;

-- A baseline workspace policy. For a multi-staff organization, implement a
-- workspace_members table and use membership checks rather than broad access.
create policy "Users can read own profile" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "Users can create own profile" on public.profiles
  for insert to authenticated with check (id = auth.uid());

create policy "Users can read their own clients" on public.clients
  for select to authenticated using (owner_id = auth.uid());
create policy "Users can insert their own clients" on public.clients
  for insert to authenticated with check (owner_id = auth.uid());
create policy "Users can update their own clients" on public.clients
  for update to authenticated using (owner_id = auth.uid())
  with check (owner_id = auth.uid());
-- Deliberately no delete policy: add a secure admin-only policy/function
-- after implementing server-verified roles. Never trust a role supplied by client.

-- Storage: create a private bucket named "client-documents" in the Supabase
-- dashboard, then add policies based on workspace membership and client access.
-- Do not make passport/visa documents public.
