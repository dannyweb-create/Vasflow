# VasFlow — Flutter + Supabase starter

A cross-platform starter for Android, iOS, Windows, macOS and Linux. It includes a Telegram-inspired clean list UI, light/dark theme, demo login, Supabase email/phone authentication, email password reset, client CRUD, local JSON cache, pipeline stages, task scratchpad, CSV export, and settings.

## Important: what is and is not production-ready

This is a **starter project**, not a fully audited visa case-management system. The user interface and basic workflows are implemented, but the following need completion before real customer data is stored:

- Supabase workspace membership and server-enforced Admin/Staff authorization.
- Secure temporary invite-code generation/consumption using a Supabase Edge Function (one-time, expiring, rate-limited).
- Private Storage bucket policies, secure document upload/download, and document metadata table.
- Payments/receipts, currency conversion source, communication log, education-history editor, smart checklist, and full audit trail.
- Encrypted offline database and conflict-aware sync. The current SharedPreferences cache is **not encrypted**.
- Automated tests, security review, app signing and platform-specific build verification.
- Private AI backend proxy. Never embed a private AI key in the Flutter client.

## Demo login

When Supabase is not configured and `VASFLOW_DEMO_MODE` is true, the login screen is prefilled with:

- Email: `wisdomobiomachim@proton.me`
- Password: `Montana@g244`

This is a **local-only demo bypass**, not a real Supabase account. Remove it before publishing. Do not reuse this password for a real account. Once Supabase is configured, create the real Admin user in Supabase Auth and assign the `admin` role securely in `profiles` through a trusted admin-only process.

## Setup

1. Install Flutter SDK and platform prerequisites: https://docs.flutter.dev/get-started/install
2. Create a Supabase project at https://supabase.com.
3. In Supabase SQL Editor, run `supabase/schema.sql`.
4. In Supabase Authentication settings, configure Email and/or Phone providers. Configure SMTP for reliable password-reset emails and set the correct Site URL / redirect URLs.
5. Add your Supabase URL and **publishable/anon key** at run time (never service_role):
   ```sh
   flutter pub get
   flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
   ```
6. Set `VASFLOW_DEMO_MODE=false` for a non-demo build:
   ```sh
   flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY --dart-define=VASFLOW_DEMO_MODE=false
   ```

### Password reset

The Forgot Password screen calls Supabase `resetPasswordForEmail`. For the email to arrive, configure SMTP/email provider, allowed redirect URLs, and the project Site URL in Supabase. Test both the email delivery and the password update flow before launch. Custom SMTP is recommended; default provider limits may apply.

### Build targets

- Android: `flutter build apk`
- iOS: `flutter build ios` (requires macOS/Xcode)
- Windows: `flutter build windows` (requires Windows toolchain)
- macOS: `flutter build macos` (requires macOS/Xcode)
- Linux: `flutter build linux` (requires Linux desktop dependencies)

Flutter generates platform directories on the machine where you build. This ZIP intentionally contains the reusable Dart source and configuration rather than generated native platform scaffolding.

## Use on Android with Acode

Acode is a code editor, not a complete Flutter SDK/build environment. On your phone:

1. Download and extract `vasflow.zip` into a folder accessible to Acode.
2. Open the extracted folder in Acode and edit `lib/` or `supabase/schema.sql`.
3. Acode alone normally cannot run `flutter pub get` or compile the app. For a real build, use a computer with Flutter installed, or a cloud IDE/build service that supports Flutter.
4. On a computer, run `flutter pub get`, then the `flutter run` command above.
5. To test on your phone, enable Android Developer Options → USB debugging and run `flutter devices`, then `flutter run`; alternatively build an APK with `flutter build apk` and install the resulting APK.
6. Do not place secret keys in Dart files or commit them to a public repository.

## Suggested next implementation milestones

1. Add workspace tables and RLS membership policies; enforce roles server-side.
2. Add Edge Functions for invite codes, admin-only deletion, audit events, and AI proxy.
3. Add private Storage upload/download with signed URLs and document metadata.
4. Add encrypted SQLite (for example, SQLCipher-backed storage) and sync queue.
5. Add payments, receipts, reminders/notifications, timeline and communication log.
6. Add integration tests and a production security review.

## Project tree

```text
vasflow/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── models/
│   ├── screens/
│   └── services/
├── supabase/schema.sql
├── pubspec.yaml
├── analysis_options.yaml
└── README.md
```
